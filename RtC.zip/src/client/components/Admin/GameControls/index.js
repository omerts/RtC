export * from './GameControls.react'

export {default as default} from './GameControls.react'
