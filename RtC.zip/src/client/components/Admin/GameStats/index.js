export * from './GameStats.react'
export {default as default} from './GameStats.react'

