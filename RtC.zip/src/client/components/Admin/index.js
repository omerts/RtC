export * from './Admin.react'
export {default as default} from './Admin.react'