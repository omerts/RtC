export * from './Register.react'

export {default as default} from './Register.react'