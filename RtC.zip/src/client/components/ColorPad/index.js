export * from './ColorPad.react'
export {default as default} from './ColorPad.react'